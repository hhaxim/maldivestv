# Maldives TV

This is a Kodi video plugin to view live streams of Maldives TV channels. It uses direct streams provided by the respective channels themselves and Dhiraagu play.mv live streams.


# Credits
Streams: Dhiraagu play.mv
Icon: Countryflags.com https://www.countryflags.com/en/maldives-flag-icon.html
Background: Pixabay.com https://pixabay.com/en/maldives-tropics-tropical-drone-1993704/